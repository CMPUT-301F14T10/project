package serializationClasses;

import java.lang.reflect.Type;


import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;


public class ReplySerializing implements JsonSerializer<Reply>{
	//This will create a jsonObject for the reply class that other serializers (like question and answer) will 
	//may end up using 
	@Override
	public JsonElement serialize(Reply reply,Type arg1,
			JsonSerializationContext arg2){
		final JsonObject replyObject= new JsonObject();
		replyObject.addProperty("reply",reply.getReply());
		replyObject.addProperty("author",reply.getAuthor());
		
		return replyObject;
	}

}