package serializationClasses;


public class Picture
{
	//Need to fix later on
	protected int picture;
	
	public Picture(int picture) {
		this.picture=picture;
	}
	public int getSize() {
		return this.picture;
	}
}
